#pragma once
#include <string>
using namespace std;
class Student
{
public:
    string studentName;
    int studentNumber;
};
