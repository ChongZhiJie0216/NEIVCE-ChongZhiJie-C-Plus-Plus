#include "Assignment02.h"
#include <iostream>
using namespace std;

int main()
{
    Menu();
}


