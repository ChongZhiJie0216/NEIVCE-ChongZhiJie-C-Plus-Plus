#ifndef Menu_H
#define Menu_H
#pragma once
#include <string>
void CourseCode();
#endif