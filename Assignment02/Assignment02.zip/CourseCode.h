#ifndef System_H
#define System_H
#pragma once
#include <string>
void StudentRegistrationEntry();
void DeleteCourseRecord();
void DeleteStudentRecord();
void CourseEnrolmentReport();
#endif#
